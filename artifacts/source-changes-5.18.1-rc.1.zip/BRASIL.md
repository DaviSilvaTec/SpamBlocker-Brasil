# SpamBlocker Brasil 5.18.1-rc.1

Base: upstream v5.18, commit 1b2bf9ec90fd9c53a0b1d973e45d3675c77198b0.

A variante `brasil` usa pacote `spam.blocker.brasil` e nome SpamBlocker Brasil,
para coexistir com o original sem exigir a chave de assinatura do autor.

Depois de falhar a busca completa de um telefone, compara o número local de uma
chamada brasileira válida com telefones de 8/9 dígitos salvos sem DDD. Não altera
a agenda, não remove o DDD de contatos completos e não aceita correspondência
ambígua entre contatos distintos. A mesma rotina é usada na identificação de SMS.

Números locais iguais podem existir em DDDs diferentes: salvar sem DDD continua
sendo uma escolha mais permissiva. Os demais sabores mantêm o comportamento original.

Compilar: `./gradlew :app:testBrasilDebugUnitTest :app:assembleBrasilDebug`.
O app original fica instalado; o papel de identificação/bloqueio de chamadas do
Android precisa ser atribuído à variante Brasil para que ela filtre chamadas reais.
Configurações do original podem ser transferidas pelo próprio Exportar/Importar.

## Validação desta entrega

- Quatro testes unitários passaram (incluindo prefixo de operadora, fixos,
  estrangeiros, números de serviço e números completos salvos com DDD).
- Quatro testes com contatos temporários no emulador passaram; os contatos de
  teste são locais e removidos ao final.
- Uma consulta instrumentada no Samsung reconheceu um contato existente salvo
  sem DDD a partir do número recebido com DDD, sem editar a agenda.
- A simulação das regras no Samsung permitiu esse contato pela regra Contatos.
- Variante selecionada como `android.app.role.CALL_SCREENING`, com contatos
  permitidos (prioridade 10), desconhecidos bloqueados (prioridade 0) e triagem
  global ligada. SMS permanece desativado nesta configuração.
- Confirmação de ligação real pendente do usuário.

O lint completo encontra 24 erros, 101 avisos e 2 sugestões na base herdada.
Os arquivos com erros foram comparados byte a byte com v5.18 e estão intactos;
nenhum erro é atribuído aos novos arquivos de comparação. Isso não equivale a
um lint global aprovado. Build e testes da variante são executados separadamente.
