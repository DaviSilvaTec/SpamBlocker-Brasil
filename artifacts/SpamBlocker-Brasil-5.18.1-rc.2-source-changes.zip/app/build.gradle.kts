plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
    kotlin("plugin.serialization") version "1.9.24"
}

android {
    // https://github.com/aj3423/SpamBlocker/issues/184
    dependenciesInfo {
        // Disables dependency metadata when building APKs.
        includeInApk = false
        // Disables dependency metadata when building Android App Bundles.
        includeInBundle = false
    }

    signingConfigs {
        create("release") {
            enableV2Signing = false
            enableV3Signing = true

            storeFile = file("../../keystore.jks")
            storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
            keyPassword = System.getenv("ANDROID_KEY_PASSWORD")
            keyAlias = System.getenv("ANDROID_KEY_ALIAS")
        }
    }
    namespace = "spam.blocker"
    compileSdk = 37

    defaultConfig {
        minSdk = 29
        targetSdk = 36
        versionCode = 518
        versionName = "5.18"
        buildConfigField("boolean", "BRAZIL_LOCAL_CONTACT_MATCHING", "false")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    flavorDimensions += "market"
    productFlavors {
        create("brasil") {
            dimension = "market"
            applicationId = "spam.blocker.brasil"
            versionCode = 51807
            versionName = "5.18.1-rc.2"
            buildConfigField("boolean", "BRAZIL_LOCAL_CONTACT_MATCHING", "true")
        }
        create("fdroid") {
            dimension = "market"
            applicationId = "spam.blocker"
        }
        create("googleplay") {
            dimension = "market"
            applicationId = "spam.blocker.googleplay"
        }
    }

    buildTypes {

        // for github action only
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            signingConfig = signingConfigs.getByName("release")
        }
        create("releaseNoR8") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
            matchingFallbacks += listOf("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        viewBinding = true
        buildConfig = true
    }

    testOptions {
        packaging {
            resources.excludes.add("META-INF/LICENSE.md")
            resources.excludes.add("META-INF/LICENSE-notice.md")
            jniLibs {
                useLegacyPackaging = true
            }
        }
    }

    // Sideload liblitertlm_jni.so from Downloads/test in Debug.summarize().
    packaging {
        jniLibs {
            excludes += "**/liblitertlm_jni.so"
        }
    }
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()
}

tasks.configureEach {
    if (name.contains("ReleaseNoR8") && name.contains("lintVital", ignoreCase = true)) {
        enabled = false
    }
}

dependencies {
    implementation(libs.androidx.browser)
    implementation(libs.androidx.runtime)
    // third-party
    implementation(libs.lazycolumnscrollbar) // for scroll bar
    implementation(libs.reorderable) // for reordering Action items with drag & drop

    // google
    implementation(libs.libphonenumber) // for checking whether 33123 and +33123 are the same number
    implementation(libs.geocoder) // geo database from libphonenumber
    implementation(libs.carrier) // carrier database from libphonenumber

    // jetbrains kotlinx
    implementation(libs.serialization.json) // for backup/restore json serialization
    implementation(libs.androidx.work.runtime.ktx) // for WorkManager

    // jetpack compose
    implementation(platform(libs.compose.bom)) // auto compose version control
    implementation(libs.compose.activity) // for ComponentActivity
    implementation(libs.compose.material3) // for components like Scaffold, Surface
    implementation(libs.compose.ui)

    // testing
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly("org.junit.platform:junit-platform-launcher:${libs.versions.junitJupiter.get()}")
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.mockk)
}
