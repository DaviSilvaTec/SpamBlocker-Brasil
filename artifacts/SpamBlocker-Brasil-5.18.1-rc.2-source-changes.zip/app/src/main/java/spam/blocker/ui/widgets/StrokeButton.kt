package spam.blocker.ui.widgets

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import spam.blocker.G
import spam.blocker.R
import spam.blocker.ui.M
import spam.blocker.ui.setting.LabeledRow
import spam.blocker.ui.thenIf
import spam.blocker.util.Lambda
import spam.blocker.util.Lambda1
import spam.blocker.util.Lambda2
import spam.blocker.util.PermissionType
import spam.blocker.util.PermissionWrapper
import spam.blocker.util.Util.inRange
import spam.blocker.util.hasFolderAccess
import spam.blocker.util.toFolderDisplayName

const val BUTTON_CORNER_RADIUS = 4
const val BUTTON_H_PADDING = 12
const val BUTTON_H = 26

// The built-in Button is based on Surface, which has a minimal width as 48dp,
//  as: minimumInteractiveComponentSize
// So customize the Button to get rid of it.
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Button(
    content: @Composable RowScope.() -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: Lambda? = null,
    enabled: Boolean = true,
    borderWidth: Dp = 1.dp,
    borderColor: Color = G.palette.textGrey,
    backgroundColor: Color = Color.Unspecified,
    shape: Shape = RoundedCornerShape(BUTTON_CORNER_RADIUS.dp),
    contentPadding: PaddingValues = PaddingValues(BUTTON_H_PADDING.dp, 0.dp),
    onClick: Lambda? = null,
) {
    val C = G.palette

    Box(
        modifier = modifier
            .heightIn(min = (if(spam.blocker.BuildConfig.BRAZIL_LOCAL_CONTACT_MATCHING) 48 else BUTTON_H).dp)
            .border(
                width = borderWidth,
                color = if (enabled) borderColor else C.disabled,
                shape = shape
            )
            .clip(RoundedCornerShape(BUTTON_CORNER_RADIUS.dp))
            .background(backgroundColor)

            .thenIf(enabled) {
                combinedClickable(
                    onClick = { onClick?.let { it() } },
                    onLongClick = { onLongClick?.invoke() }
                )
            },
        propagateMinConstraints = true
    ) {
        RowCenter(
            Modifier.padding(contentPadding),
        ) {
            content()
        }
    }
}


@Composable
fun StrokeButton(
    label: String? = null,
    color: Color,
    icon: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
    onLongClick: Lambda? = null,
    shape: RoundedCornerShape = RoundedCornerShape(BUTTON_CORNER_RADIUS.dp),
    contentPadding: PaddingValues = PaddingValues(BUTTON_H_PADDING.dp, 0.dp),
    enabled: Boolean = true,
    onClick: Lambda? = null,
) {
    Button(
        modifier = modifier.heightIn(min = (if(spam.blocker.BuildConfig.BRAZIL_LOCAL_CONTACT_MATCHING) 48 else BUTTON_H).dp),
        enabled = enabled,
        onLongClick = onLongClick,
        contentPadding = contentPadding,
        borderColor = color,
        shape = shape,
        onClick = onClick,
        content = {
            RowVCenterSpaced(4) {
                icon?.let { it() }
                label?.let {
                    Text(
                        text = label, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    )
}


@Composable
fun ToggleButton(
    enabled: Boolean,
    content: @Composable RowScope.() -> Unit,
    modifier: Modifier = Modifier,
    onClick: Lambda,
) {
    val C = G.palette
    Box(
        modifier = modifier.wrapContentSize()
    ) {
        Button(
            modifier = modifier,
            borderWidth = if (enabled) 2.dp else 1.dp,
            borderColor = if (enabled) C.textGrey else C.disabled,
            content = content,
            onClick = onClick
        )

        if (enabled) {
            Canvas(
                modifier = Modifier
                    .size(5.dp)
                    .align(Alignment.CenterStart)
                    .offset(x = 5.dp)
            ) {
                drawCircle(color = C.success, radius = size.minDimension / 2)
            }
        }
    }
}


@Composable
fun GreyButton(
    label: String,
    // optional
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: Lambda? = null,
) {
    StrokeButton(
        label = label,
        color = G.palette.textGrey,
        modifier = modifier,
        enabled = enabled,
        onClick = onClick,
    )
}


@Composable
fun FooterButton(
    label: String? = null,
    color: Color = G.palette.textGrey,
    icon: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,

    footerIconId: Int,
    footerSize: Int,
    footerColor: Color = color,
    footerOffset: Pair<Int, Int> = Pair(-3, -3),

    onLongClick: Lambda? = null,
    onClick: Lambda? = null,
) {
    val C = G.palette

    Box(
        modifier = modifier.wrapContentSize()
    ) {
        StrokeButton(
            label = label,
            icon = icon,
            color = color,
            modifier = modifier,
            onClick = onClick,
            enabled = enabled,
            onLongClick = onLongClick,
        )

        Icon(
            imageVector = ImageVector.vectorResource(footerIconId),
            contentDescription = "",
            tint = if (enabled) footerColor else C.disabled,
            modifier = Modifier
                .size(footerSize.dp)
                .align(Alignment.BottomEnd)
                .offset(footerOffset.first.dp, footerOffset.second.dp)
        )
    }
}

@Composable
fun LongPressButton(
    label: String,
    color: Color,
    footerIconId: Int = R.drawable.ic_time_slot,
    onClick: Lambda,
    onLongClick: Lambda,
) {
    FooterButton(
        label = label,
        color = color,
        footerIconId = footerIconId,
        footerSize = 9,
        footerOffset = Pair(-3, -3),
        onClick = onClick,
        onLongClick = onLongClick,
    )
}

// Show icon only, label only, or both
enum class ComboDisplayType {
    Label, Icon, IconLabel,
}

// Button with a small triangle sign at the bottom right,
//  the label always follows the selected item
@Composable
fun ComboBox(
    items: List<LabelItem>,
    selected: Int,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    displayType: ComboDisplayType = ComboDisplayType.Label, // show label/icon/both
    color: Color = G.palette.textGrey,
    warning: (@Composable () -> Unit)? = {
        ResIcon(R.drawable.ic_question_circle, color = G.palette.warning, modifier = M.size(18.dp))
    },
    footerOffset: Pair<Int, Int> = Pair(-4, -4),
    footerSize: Int = 6,
    footerIconId: Int = R.drawable.ic_dropdown_footer,
    onLongClick: Lambda? = null,
    expander: Lambda1<MutableState<Boolean>> = { it.value = true },
) {
    DropdownWrapper(
        items = items,
    ) { expanded ->
        FooterButton(
            label = if (!inRange(selected, items))
                null
            else
                when (displayType) {
                    ComboDisplayType.Label, ComboDisplayType.IconLabel -> items[selected].label
                    else -> null
                },
            icon = if (!inRange(selected, items))
                warning
            else
                when (displayType) {
                    ComboDisplayType.Icon, ComboDisplayType.IconLabel -> {
                        {
                            items[selected].leadingIcon?.let { it() }
                        }
                    }
                    else -> null
                },
            color = color,
            modifier = modifier,
            enabled = enabled,
            onLongClick = onLongClick,
            footerOffset = footerOffset,
            footerSize = footerSize,
            footerIconId = footerIconId,
        ) {
            expander(expanded)
        }
    }
}


// Button with a small triangle sign at the bottom right,
//  has a fixed label.
@Composable
fun MenuButton(
    label: String,
    items: List<IMenuItem>,
    modifier: Modifier = Modifier,
    color: Color = G.palette.textGrey,
) {
    DropdownWrapper(items = items) { expanded ->
        FooterButton(
            label = label,
            color = color,
            modifier = modifier,
            footerOffset = Pair(-4, -4),
            footerSize = 6,
            footerIconId = R.drawable.ic_dropdown_footer,
        ) {
            expanded.value = true
        }
    }
}


// Same as MenuButton but shows different menus for short/long tap.
@Composable
fun MenuButton(
    label: String,
    items: List<IMenuItem>,
    longTapItems: List<IMenuItem>,
    modifier: Modifier = Modifier,
    footerIconId: Int = R.drawable.ic_time_slot,
    color: Color = G.palette.textGrey,
) {
    DropdownWrapper(items = items) { expandedForTap ->
        DropdownWrapper(items = longTapItems) { expandedForLongTap ->
            FooterButton(
                label = label,
                color = color,
                modifier = modifier,
                footerOffset = Pair(-3, -3),
                footerSize = 9,
                footerIconId = footerIconId,
                onClick = {
                    expandedForTap.value = true
                },
                onLongClick = {
                    expandedForLongTap.value = true
                }
            )
        }
    }
}


/*
  A setting button that typically contains two options:
   - a switchbox, e.g. "Never Expire"
   - a number inputbox for duration, hidden when the switch is on
 */
@Composable
fun DurationButton(
    alwaysEnabled: Boolean,
    alwaysLabelId: Int,
    onEnableChange: Lambda1<Boolean>,

    duration: Int?,
    onDurationChange: Lambda2<Int?, Boolean>,
    durationLabelId: Int,
    unitLabelId: Int = R.plurals.days
) {
    val trigger = remember { mutableStateOf(false) }
    PopupDialog(
        trigger = trigger,
    ) {
        // switchbox enabled
        LabeledRow(alwaysLabelId) {
            SwitchBox(checked = alwaysEnabled, onCheckedChange = onEnableChange)
        }

        // duration days
        if (!alwaysEnabled) {
            NumberInputBox(
                intValue = duration,
                onValueChange = onDurationChange,
                labelId = durationLabelId,
                leadingIconId = R.drawable.ic_duration,
            )
        }
    }

    GreyButton(
        label = if (!alwaysEnabled) {
            PluralStr(duration!!, unitLabelId)
        } else {
            Str(alwaysLabelId)
        }
    ) {
        trigger.value = true
    }
}

/*
  A button for choosing dir, the param `uri` will be updated after a dir is selected.
 */
@Composable
fun DirButton(
    uri: MutableState<Uri?>,
) {
    val ctx = LocalContext.current

    StrokeButton(
        label = if (uri.value == null)
            Str(R.string.choose)
        else
            uri.value!!.toFolderDisplayName(),

        icon = if (uri.value?.hasFolderAccess(ctx) == true)
            null
        else if (uri.value == null) {
            null
        } else {
            { ResIcon(R.drawable.ic_lock, modifier = M.size(16.dp), color = G.palette.warning) }
        },

        color = G.palette.textGrey,
    ) {
        val perm = PermissionType.SafDirAccess(uri = uri.value)

        G.permissionChain.ask(
            ctx,
            listOf(PermissionWrapper(perm))
        ) { granted ->
            if (granted) {
                // After a dir is selected, the `perm.uri` is the selected Uri

                // Make sure `uri` is changed, to force this button to recompose, otherwise the lock icon won't disappear
                uri.value = null

                uri.value = perm.uri
            }
        }
    }
}
